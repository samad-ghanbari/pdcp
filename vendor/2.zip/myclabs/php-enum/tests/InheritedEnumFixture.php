<?php

namespace MyCLabs\Tests\Enum;

/**
 * Class InheritedEnumFixture.
 * @package MyCLabs\Tests\Enum
 *
 * @method static InheritedEnumFixture VALUE()
 */
class InheritedEnumFixture extends EnumFixture
{
    const VALUE = 'value';
}
